define(['jquery', 'core/log', 'mod_readaloud/deps'], function ($, log, Deps) {
    "use strict"; // jshint ;_;
    /*
    This file is just to help stage the loading of dependencies correctly. partic tether
     */

    log.debug('Readaloud loader: initialising');

    return {};//end of return value
});